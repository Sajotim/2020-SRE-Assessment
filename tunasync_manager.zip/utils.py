import json
from concurrent.futures import ThreadPoolExecutor
import wget
import requests
import tarfile
import bz2
import os
import configparser
import delegator
import distro
import platform
import time

executor = ThreadPoolExecutor(8)
manager_conf = configparser.ConfigParser()
worker_conf = configparser.ConfigParser()
ctl_conf = configparser.ConfigParser()
# systemd_manger = configparser.ConfigParser()
# systemd_worker = configparser.ConfigParser()
path = os.getcwd()
manager_ssl = 0
with open('worker.json', 'r') as rf:
    work = rf.read()
worker_list = eval(work)
rf.close()


### 安装部分开始
def bin():
    try:
        try:
            res = requests.get("https://api.github.com/repos/tuna/tunasync/releases/latest")
        except:
            res = requests.get("https://api.git.sdut.me/repos/tuna/tunasync/releases/latest")
        dl_url = res.json()['assets'][0]['browser_download_url']
        if dl_url:
            print("Get download URL:" + dl_url)
            try:
                filename = wget.download(dl_url, 'tunasync-linux-bin.tar.bz2')
                print("Download success")
            except:
                dl_url = str(dl_url).replace('github.com', 'github.com.cnpmjs.org')
                print("Try " + dl_url)
                filename = wget.download(dl_url, 'tunasync-linux-bin.tar.bz2')
                print("Download success")
            try:
                archive = tarfile.open(filename, 'r:bz2')
                archive.debug = 1
                for tarinfo in archive:
                    archive.extract(tarinfo, r'.')
                archive.close()
                print("Unzip success")
                try:
                    os.remove(filename)
                except:
                    pass
                delegator.run("chmod +x tunasync tunasynctl")
                delegator.run("mv tunasync tunasynctl /usr/bin")
            except:
                print("Unzip failed")
                try:
                    os.remove(filename)
                except:
                    pass
        else:
            print("Get download URL error")
            return -1
    except:
        print("Get bin error")
        return -1


# 备用的方法
def go_bin():
    print("Install Go...")
    plat = platform.machine()
    print("当前处理器架构为" + plat)
    if plat == "x86_64":
        mode = 'amd64'
    elif plat == "i386":
        mode = '386'
    elif plat == "aarch64":
        mode = 'arm64'
    elif plat == "arm":
        choice = input("ARM 32位处理器有极大概率无法完成环境配置，是否继续(Y/N)")
        if choice == 'y' or choice == 'Y':
            pass
        else:
            print("终止环境配置...")
            return 0
        mode = 'armv6l'
    else:
        print("Unsupport CPU Type")
        return 0
    url = "https://golang.org/dl/go1.14.4.linux-" + mode + ".tar.gz"
    filename = 'go1.14.4.tar.gz'
    print("Golang download from:" + url)
    wget.download(url, filename)
    print("Start Untar")
    archive = tarfile.open(filename)
    archive.extractall(path='go_bin/')
    archive.close()
    print("Untar Succeed")
    delegator.run("mv go_bin/bin/* /usr/bin/")
    print("Install Golang Succeed")


# 改用软件包管理器配置
def go():
    print("Install Go...")
    like = distro.info()['like']
    print("当前系统为" + like)
    if like == "ubuntu":
        print("配置软件源...")
        cmd = delegator.run("add-apt-repository ppa:longsleep/golang-backports")
        if cmd.return_code == 0:
            print("成功")
        print("更新缓存...")
        cmd = delegator.run("apt update")
        if cmd.return_code == 0:
            print("完成")
        print("安装Golang")
        cmd = delegator.run("apt install golang-go -y")
        if cmd.return_code == 0:
            print("安装完成")
        else:
            print("尝试使用二进制文件方式安装...")
            go_bin()
    elif like.find("rhel") >= 0:
        print("安装epel")
        cmd = delegator.run("yum install epel-release -y")
        if cmd.return_code == 0:
            print("成功")
        print("安装Golang")
        cmd = delegator.run("yum install golang -y")
        if cmd.return_code == 0:
            print("安装完成")
    else:
        print("暂不支持的发行版...\n尝试使用二进制文件方式安装...")
        go_bin()
    print("换用国内镜像源")
    delegator.run("go env -w GO111MODULE=on")
    delegator.run("go env -w GOPROXY=https://goproxy.cn,direct")


def dep():
    go()
    like = distro.info()['like']
    if like == "ubuntu":
        print("更新缓存...")
        cmd = delegator.run("apt update")
        if cmd.return_code == 0:
            print("完成")
        print("安装 git make")
        cmd = delegator.run("apt install -y git make")
        if cmd.return_code == 0:
            print("安装完成")
    elif like.find("rhel") >= 0:
        print("安装 git make")
        cmd = delegator.run("yum install git make -y")
        if cmd.return_code == 0:
            print("安装完成")
    else:
        print("暂不支持的发行版")
        return 0


def build():
    dep()
    print("克隆项目")
    try:
        os.remove("tunasync")
    except:
        pass
    cmd = delegator.run("git clone https://github.com/tuna/tunasync.git")
    if cmd.return_code == 0:
        print("完成")
    print("开始编译")
    cmd = delegator.run("cd tunasync && make")
    if cmd.return_code == 0:
        print("编译完成")
    print("验证结果...")
    code = 1
    cmd = delegator.run("cd tunasync/build && ./tunasync -v")
    print(cmd.out)
    if cmd.return_code != 0:
        code = 0
    cmd = delegator.run("cd tunasync/build && ./tunasynctl -v")
    print(cmd.out)
    if cmd.return_code != 0:
        code = 0
    if code == 1:
        delegator.run("mv tunasync/build/* /usr/bin")
        print("验证完成")
    else:
        print("失败")
        return 0
### 安装部分结束


### 基础设置部分开始
def ssl(mode):
    global manager_ssl
    if mode == 0:
        type = input("是否为manager设置SSL(Y/N)")
        manager_conf['server']['ssl_cert'] = '\"\"'
        manager_conf['server']['ssl_key'] = '\"\"'
        if type == 'Y' or type == 'y':
            confirm = input("确认证书文件在ssl/manager目录下，并分别命名为ssl.pem ssl.key(Y/N)")
            if confirm == 'Y' or confirm == 'y':
                manager_conf['server']['ssl_cert'] = "\"" + path + '/ssl/manager/ssl.pem\"'
                manager_conf['server']['ssl_key'] = "\"" + path + '/ssl/manager/ssl.key\"'
                print("同时，别忘了将ca_cert也放置在ssl/manager目录下，并命名为ca.cert")
                manager_ssl = 1
            else:
                print("请放置好文件后重新配置")
                return -1
        else:
            return 0
    else:
        worker_conf['server']['ssl_cert'] = '\"\"'
        worker_conf['server']['ssl_key'] = '\"\"'
        if manager_ssl:
            worker_conf['manager']['ca_cert'] = "\"" + path + '/ssl/manager/ca.cert\"'
        type = input("是否为worker设置SSL(Y/N)")
        if type == 'Y' or type == 'y':
            confirm = input("确认证书文件在ssl/worker目录下，并分别命名为ssl.pem ssl.key(Y/N)")
            if confirm == 'Y' or confirm == 'y':
                worker_conf['server']['ssl_cert'] = "\"" + path + '/ssl/worker/ssl.pem\"'
                worker_conf['server']['ssl_key'] = "\"" + path + '/ssl/worker/ssl.key\"'
            else:
                print("请放置好文件后重新配置")
                return -1
        else:
            return 0


# 暂不允许修改
def db():
    manager_conf['files'] = {}
    # db_type = input("数据库类型：(bolt)")
    # if db_type:
    #     pass
    # else:
    db_type = 'bolt'
    manager_conf['files']['db_type'] = "\"" + db_type + "\""
    # db_file = input("数据库文件位置(db/manager.db)")
    # if db_file:
    #     pass
    # else:
    db_file = path + '/db/manager.db'
    manager_conf['files']['db_file'] = "\"" + db_file + "\""
    # ca_cert = input("ca cert()")
    # if db_type:
    #     pass
    # else:
    ca_cert = ''
    manager_conf['files']['ca_cert'] = "\"" + ca_cert + "\""


def init_manager():
    debug = input("是否开启Debug(Y/N)")
    if debug == 'Y' or debug == 'y':
        manager_conf['DEFAULT'] = {'debug': 'true'}
    else:
        manager_conf['DEFAULT'] = {'debug': 'false'}
    manager_conf['server'] = {}
    bind_ip = input("绑定IP：(127.0.0.1)")
    if bind_ip:
        pass
    else:
        bind_ip = '127.0.0.1'
    manager_conf['server']['addr'] = "\"" + bind_ip + "\""
    bind_port = input("绑定端口：(14242)")
    if bind_port:
        pass
    else:
        bind_port = str(14242)
    manager_conf['server']['port'] = bind_port
    ssl(0)
    db()
    try:
        os.mkdir('/etc/tunasync')
    except:
        pass
    with open('/etc/tunasync/manager.conf', 'w') as mf:
        manager_conf.write(mf)
    mf.close()
    ctl_conf = {"manager_addr": "\"" + bind_ip + "\"", "manager_port": bind_port}
    if manager_ssl:
        ctl_conf["ca_cert"] = "\"" + path + '/ssl/manager/ca.cert\"'
    with open('/etc/tunasync/ctl.conf', 'w') as cf:
        manager_conf.write(cf)
    cf.close()


def add_worker():
    name = input("输入Worker名：(不能重复)")
    worker_conf['global'] = {'name': "\"" + name + "\"", "log_dir": "\"logs/{{.Name}}\""}
    dir = input("输入放置镜像文件的目录：(以/结尾)")
    worker_conf['global']['mirror_dir'] = "\"" + dir + "\""
    con = input("输入线程数：(10)")
    if con:
        pass
    else:
        con = str(10)
    worker_conf['global']['concurrent'] = con
    interval = input("输入同步的周期(分钟)：(1)")
    if interval:
        pass
    else:
        interval = str(1)
    worker_conf['global']['interval'] = interval
    api = input("输入manager地址(http://127.0.0.1:14242)：")
    if api:
        pass
    else:
        api = "http://127.0.0.1:14242"
    token = input("输入token：")
    worker_conf['manager'] = {"api_base": "\"" + api + "\"", "token": "\"" + token + "\""}
    cgroup = input("是否开启cgroup(Y/N)")
    if cgroup == 'Y' or cgroup == 'y':
        base_path = input("输入base_path：")
        group = input("输入group：")
        worker_conf['cgroup'] = {'enable': 'true', 'base_path': "\"" + base_path + "\"", 'group': "\"" + group + "\""}
    else:
        base_path = ""
        group = ""
        worker_conf['cgroup'] = {'enable': 'false', 'base_path': "\"" + base_path + "\"", 'group': "\"" + group + "\""}
    hostname = input("输入主机名：")
    try:
        ip = requests.get('https://api-ipv4.ip.sb/ip').text[:-1]
    except:
        ip = '0.0.0.0'
    listen_addr = input("绑定IP：(" + ip + ")")
    if listen_addr:
        pass
    else:
        listen_addr = ip
    listen_port = input("绑定端口：(6000)(端口不能重复)")
    if listen_port:
        pass
    else:
        listen_port = str(6000)
    worker_conf['server'] = {'hostname': "\"" + hostname + "\"", 'listen_addr': "\"" + listen_addr + "\"", 'listen_port': listen_port}
    ssl(1)
    mirror_name = '\"' + input("输入mirror名称：") + '\"'
    provider = '\"' + input("输入同步方式：") + '\"'
    upstream = '\"' + input("输入同步源：") + '\"'
    command = ''
    if provider == "command":
        command = '\"' + input("输入同步脚本位置(绝对路径)：") + '\"'
    elif provider == "rsync":
        pass
        # 暂不编写
        # rsync_options = [" "]
    else:
        pass
    c = input("是否启用ipv6?(Y/N)")
    if c == 'Y' or c == 'y':
        use_ipv6 = 'true'
    else:
        use_ipv6 = 'false'
    memory_limit = '\"' + input("内存限制(不填不限制)：") + '\"'
    # exclude_file
    worker_conf['[mirrors]'] = {"name": mirror_name, "provider": provider, "upstream": upstream, "use_ipv6": use_ipv6}
    if command:
        worker_conf['[mirrors]']['command'] = command
    if memory_limit:
        worker_conf['[mirrors]']['memory_limit'] = memory_limit
    with open('/etc/tunasync/worker-' + name + '.conf', 'w') as wf:
        worker_conf.write(wf)
    wf.close()
    worker_list[name] = {mirror_name: dir + mirror_name}
    with open('worker.json', 'w') as cf:
        cf.write(json.dumps(worker_list))
    cf.close()
    return name


# 仅设置systemd，不设启动且不执行
def systemd():
    # 由于大小写问题，改用预配置文件
    # systemd_manger['Unit'] = {}
    # systemd_manger['Service'] = {}
    # systemd_manger['Install'] = {}
    # systemd_manger['Unit']['Description'] = "tunasync_manger"
    # systemd_manger['Unit']['After'] = "network.service"
    # systemd_manger['Unit']['Requires'] = "network.service"
    # systemd_manger['Service']['Type'] = "simple"
    # systemd_manger['Service']['User'] = "root"
    # systemd_manger['Service']['PermissionsStartOnly'] = "true"
    # systemd_manger['Service']['ExecStart'] = "/usr/bin/tunasync manager --config /etc/tunasync/conf/manager.conf --with-systemd"
    # systemd_manger['Service']['ExecReload'] = "/bin/kill -SIGHUP $MAINPID"
    # systemd_manger['Install']['WantedBy'] = "multi-user.target"
    # systemd_worker['Unit'] = {}
    # systemd_worker['Service'] = {}
    # systemd_worker['Install'] = {}
    # systemd_worker['Unit']['Description'] = "tunasync_worker"
    # systemd_worker['Unit']['After'] = "network.service"
    # systemd_worker['Service']['Type'] = "simple"
    # systemd_worker['Service']['User'] = "root"
    # systemd_worker['Service']['ExecStart'] = "/usr/bin/tunasync worker --config /etc/tunasync/conf/worker.conf --with-systemd"
    # systemd_worker['Install']['WantedBy'] = "multi-user.target"
    # 开始设置systemd
    print("终止Manager...")
    cmd = delegator.run("systemctl stop tunasync_manger")
    print(cmd.out)
    print("终止Worker...")
    cmd = delegator.run("systemctl stop tunasync_worker")
    print(cmd.out)
    #try:
    #    os.remove('tunasync_manger.service')
    #except:
    #    pass
    #with open('tunasync_manger.service', 'w') as tmf:
    #    systemd_manger.write(tmf)
    #tmf.close()
    #try:
    #    os.remove('tunasync_worker@.service')
    #except:
    #    pass
    #with open('tunasync_worker@.service', 'w') as twf:
    #    systemd_worker.write(twf)
    #twf.close()
    delegator.run("cp -f systemd/tunasync_manager.service /etc/systemd/system/")
    delegator.run("cp -f systemd/tunasync_worker@.service /etc/systemd/system/")
    print("重载...")
    c = delegator.run("systemctl daemon-reload")
    if c.return_code == 0:
        print("成功")
### 基础设置部分结束


### systemd管理部分开始
def get_proc_status(mode, name = ''):
    if mode == 'manager':
        return delegator.run("systemctl status tunasync_manager").out
    elif mode == 'worker':
        return delegator.run("systemctl status tunasync_worker@" + name).out


def enable_autostart_manager():
    print(delegator.run("systemctl enable tunasync_manager").out)


def enable_autostart_worker(name):
    print(delegator.run("systemctl enable tunasync_worker@" + name).out)


def proc_start(mode, name = ''):
    if mode == 'manager':
        return delegator.run("systemctl start tunasync_manager").out
    elif mode == 'worker':
        return delegator.run("systemctl start tunasync_worker@" + name).out
### systemd管理部分结束


### worker管理开始
def get_json():
    return json.dumps(delegator.run("tunasynctl list --all").out)


def del_worker(name):
    print("结束进程...")
    print(delegator.run("systemctl stop tunasync_worker@" + name).out)
    print("删除文件...")
    for mirror in worker_list[name]:
        print(delegator.run("rm -rf " + worker_list[name][mirror] + ' /etc/tunasync/worker-' + name).out)
    print("删除worker...")
    delegator.run("tunasynctl rm-worker -w " + name)
    worker_list.pop(name)
    with open('worker.json', 'w') as df:
        df.write(json.dumps(worker_list))
    df.close()


def get_size(name):
    for mirror in worker_list[name]:
        return delegator.run("du -sh " + worker_list[name][mirror] + " | awk '{print $1}'").out


def refresh_size_one(name):
    for mirror in worker_list[name]:
        size = delegator.run("du -sh " + worker_list[name][mirror] + " | awk '{print $1}'").out
        print(delegator.run("tunasynctl set-size -w " + name + " " + mirror + " " + size).out)


# 需要改为Cron方式
def refresh_size():
    for worker in worker_list:
        refresh_size_one(worker)
        print("等待1min继续计算...")
        time.sleep(60)


def auto_refresh_size():
    executor.submit(refresh_size)


def cal_time(name):
    list = get_json()
    for worker in list:
        if worker['name'] == name:
            end_time = worker['last_ended_ts']
            start_time = worker['last_started_ts']
            pass_time = end_time - start_time
            return pass_time


def retry_once(name):
    list = get_json()
    for worker in list:
        if worker['name'] == name and worker['status'] == 'failed':
            print(name + "执行失败，开始重试...")
            delegator.run("systemctl restart tunasync_worker@" + name)
    return 0


# 需要改为Cron方式
def retry():
    while 1:
        for worker in worker_list:
            retry_once(worker)
            print("等待5s继续检查...")
            time.sleep(5)


def auto_retry():
    executor.submit(retry)
### worker管理结束
