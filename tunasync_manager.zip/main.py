from utils import bin, build, init_manager, add_worker, systemd, get_proc_status, proc_start, enable_autostart_manager, enable_autostart_worker, worker_list, del_worker, auto_refresh_size, cal_time, auto_retry, get_size

mode = int(input("欢迎使用tunasync管理系统，请选择功能：(首次需进行初始化)\n1.初始化\n2.新增一个Worker\n3.管理Workers\n"))
if mode == 1:
    mode2 = int(input("1.通过预编译文件方式\n2.通过编译方式\n"))
    if mode2 == 1:
        bin()
        print("开始设置manager...")
        init_manager()
        print("开始设置服务...")
        systemd()
        print("启动manager...")
        proc_start('manager')
        print("设置manager自启...")
        enable_autostart_manager()
    else:
        build()
        print("开始设置manager...")
        init_manager()
        print("开始设置服务...")
        systemd()
        print("启动manager...")
        proc_start('manager')
        print("设置manager自启...")
        enable_autostart_manager()
elif mode == 2:
    name = add_worker()
    print("启动worker...")
    proc_start('worker', name)
    print("设置worker自启...")
    enable_autostart_worker(name)
elif mode == 3:
    print("序号\t名称\t镜像名\t大小\t上次同步用时")
    i = 0
    for worker in worker_list:
        for mirror in worker_list[worker]:
            print(str(i) + '\t' + worker + '\t' + mirror + '\t' + get_size(worker) + '\t' + cal_time(worker))
            i += 1
    id = input("输入需要操作的worker序号：")
    i = 0
    for worker in worker_list:
        if i == id:
            name = worker
        i += 1
    mode2 = int(input("请选择操作：\n1.获取进程状态\n2.删除worker\n3.启用同步错误自动重试\n4.启用自动更新大小\n"))
    if mode2 == 1:
        get_proc_status('worker', name)
    elif mode2 == 2:
        del_worker(name)
    elif mode2 == 3:
        auto_retry()
    elif mode2 == 4:
        auto_refresh_size()
