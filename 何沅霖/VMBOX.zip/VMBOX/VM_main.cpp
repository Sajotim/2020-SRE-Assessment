#include <iostream>
#include <string>

enum {
    HEL = 0,
    PUT,
    MOV,
    ADD,
    SUB,
    DIV,
    MUL,
    XOR,
    OR,
    AND,
    CJP,
    JMP,
    OUT,
    inst_c//����������ָ�������ָ�������������
};//ָ�

enum {
    D_OUT ,
    D_IN ,
};//������Դ��ʶ��

enum {
    axi = 0,
    bxi,
    cxi,
    dxi,
    exi,
    fxi,
    gxi,
    hxi,
    reg_c//�����������Ĵ��������ӼĴ���������������
};//�Ĵ�����д�����ã�

enum {
    RUN = 1,
    DEBUG,
    _reg,
    _inst,
    _out,
};//����

double reg[reg_c];//ģ��Ĵ���

int memory[INT8_MAX];//ģ���ڴ�

const int program[INT8_MAX] = {
        PUT , D_OUT , 3,  //0000-0002
        MOV , bxi , cxi ,       //0003-0005
        CJP , cxi , 43 , 5 , //0006-0009
        ADD ,               //0010
        JMP , 42 ,          //0011-0012
        CJP , cxi , 45 , 5 , //0013-0016
        SUB ,               //0017
        JMP , 35 ,          //0018-0019
        CJP , cxi , 47 , 5 , //0020-0023
        DIV ,               //0024
        JMP , 28 ,          //0025-0026
        CJP , cxi , 42 , 5 , //0027-0030
        MUL ,
        JMP , 21 ,
        CJP , cxi , 94 , 5 ,
        XOR ,
        JMP , 14 ,
        CJP , cxi , 124 , 5 ,
        OR ,
        JMP , 7 ,
        CJP , cxi , 38 , 5 ,
        AND ,
        OUT , axi ,
        HEL
};//����

class VM_BOX{
private:
    int m_address; //ģ���ڴ��ַ
    int flag; //���б�־
    int r_address; //�Ĵ�����ַ
    int debug; //���Ա�־
    std::string inst_order,reg_order;//ָ��˳��,��������

public:
    void d_info(int op,int index = -1){
        std::string R[reg_c] = {"axi","bxi","cxi","dxi","exi","fxi","gxi","hxi"};
        std::string I[inst_c] = {"HEL","PUT","MOV","ADD","SUB","DIV","MUL","XOR","OR","AND","CJP","JMP","OUT"};
        if (op == _reg){
            reg_order += std::to_string((int)reg[index]);
            reg_order += "���뵽";
            reg_order += R[index];
            reg_order += ",";
        }
        else if (op == _inst) {
            if (index != HEL) {
                inst_order += I[index];
                inst_order += "->";
            }
            else
                inst_order += I[index];
        }
        else if (op == _out && debug) {
            std::cout << "ģ��ָ�����˳��:" << inst_order << std::endl;
            std::cout << "��������:" << reg_order << std::endl;
        }
    }
    void initialization(int f_debug){ //��ʼ�������
        m_address = 0;
        flag = 1;
        r_address = 0;
        debug = f_debug;
    }

    static void load_to_memory(){ //���س���ģ���ڴ�
        std::copy(std::begin(program),std::end(program),std::begin(memory));
    };

    void boot(){
        while (flag){ //����ָ�����
            instruct(memory[m_address++]);
        }
    }

    void instruct(int op){ // ִ��ָ��
        switch (op) {
            case HEL:{
                d_info(_inst, HEL);
                flag = 0;
                std::cout << "���" << std::endl;
                d_info(_out);
                break;
            }
            case PUT:{
                d_info(_inst, PUT);
                if (memory[m_address] == D_OUT) {
                    for (; r_address<memory[m_address+1] && memory[m_address+1]<=reg_c; ++r_address) {
                        char t;
                        std::cin >> t;
                        if (isdigit(t)) {
                            reg[r_address] = t - '0';
                            d_info(_reg,r_address);
                        }
                        else {
                            reg[r_address] = t;
                            d_info(_reg,r_address);
                        }
                    }
                }
                if (memory[m_address] == D_IN){
                    reg[r_address] = memory[m_address+1];
                    d_info(_reg,r_address);
                    ++r_address;
                }
                m_address += 2;
                break;
            }
            case MOV:{
                d_info(_inst, MOV);
                reg[memory[m_address]] = reg[memory[m_address]] + reg[memory[m_address+1]];
                d_info(_reg,memory[m_address]);
                reg[memory[m_address+1]] = reg[memory[m_address]] - reg[memory[m_address+1]];
                d_info(_reg,memory[m_address+1]);
                reg[memory[m_address]] = reg[memory[m_address]] - reg[memory[m_address]+1];
                d_info(_reg,memory[m_address]);
                m_address += 2;
                break;
            }
            case ADD:{
                d_info(_inst, ADD);
                reg[axi] = reg[axi] + reg[bxi];
                d_info(_reg,axi);
                break;
            }
            case SUB:{
                d_info(_inst, SUB);
                reg[axi] = reg[axi] - reg[bxi];
                d_info(_reg,axi);
                break;
            }
            case DIV:{
                d_info(_inst, DIV);
                if (reg[bxi]){
                    reg[axi] = reg[axi] / reg[bxi];
                    d_info(_reg,axi);
                    break;
                }
                else{
                    std::cout << "��������Ϊ0";
                    instruct(HEL);
                    break;
                }
            }
            case MUL:{
                d_info(_inst, MUL);
                reg[axi] = reg[axi] * reg[bxi];
                d_info(_reg,axi);
                break;
            }
            case XOR:{
                d_info(_inst, XOR);
                reg[axi] = (int)reg[axi] ^ (int)reg[bxi];
                d_info(_reg,axi);
                break;
            }
            case OR:{
                d_info(_inst, OR);
                reg[axi] = (int)reg[axi] | (int)reg[bxi];
                d_info(_reg,axi);
                break;
            }
            case AND:{
                d_info(_inst, AND);
                reg[axi] = (int)reg[axi] & (int)reg[bxi];
                d_info(_reg,axi);
                break;
            }
            case CJP:{
                d_info(_inst, CJP);
                if (memory[m_address+1] == reg[memory[m_address]]) {
                    m_address += 3;
                    break;
                }
                else {
                    m_address = m_address + memory[m_address+2] + 1;
                    break;
                }
            }
            case JMP:{
                d_info(_inst, JMP);
                m_address += memory[m_address] - 1;
                break;
            }
            case OUT:{
                d_info(_inst, OUT);
                std::cout << reg[memory[m_address]] << std::endl;
                break;
            }
        }
    }

};

void show(){
    std::cout<<"__     ____  __ ____   _____  __\n"
               "\\ \\   / /  \\/  | __ ) / _ \\ \\/ /\n"
               " \\ \\ / /| |\\/| |  _ \\| | | \\  / \n"
               "  \\ V / | |  | | |_) | |_| /  \\ \n"
               "   \\_/  |_|  |_|____/ \\___/_/\\_\\\n"
               "       1.����        2����   \n";

}

void run(int f_debug = false){
    VM_BOX start,*BOX;
    BOX = &start;
    BOX ->initialization(f_debug);
    BOX ->load_to_memory();
    BOX ->boot();
}

void choice(int cp){
    if (cp == RUN){
        std::cout << "�������У������������(֧�����򣬰�λ��򣬰�λ�룬��λ������)" << std::endl;;
        run();
    }
    else if (cp == DEBUG){
        std::cout << "�������У������������" << std::endl << "������Ϻ�����ָ�����˳�����������" << std::endl;;
        run(true);
    }
    else {
        std::cout << "�������" <<std::endl;
    }
}

int main() { //��ʼ��
    show();
    int cp;
    std::cout << "��ѡ����:";
    std::cin >> cp;
    choice(cp);
    //system("pause");
    return 0;
}